Instruction
Peter Dudley
4/3/2017
1) Selected a vector grid form the drop down menu.
2) Select a file destination and name.  The program will append �.Data� to the file name. 
